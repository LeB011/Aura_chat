# Aura Hub — Product Requirements Document (PRD)

## Vision
Aura Hub is a premium SaaS control center for personal AI agents, designed
to grow into a commercial multi-tenant product for Swiss/EU SMEs.
The V1 focuses on **Prospect AI**, a B2B prospection assistant with human-in-the-loop.

## Personas
- **Founder / Sales SME owner** (primary user, non-technical). Wants to find, qualify
  and engage B2B leads while keeping control (validation before send).
- **Future customer teams** (Owner/Admin/Member roles) — architecture ready but not activated in V1.

## Architecture
- Backend: FastAPI (routes/, providers/, services/, models.py, auth.py, db.py)
- Frontend: React + Tailwind + shadcn/ui + recharts + framer-motion (optional)
- DB: MongoDB (users, organizations, agents, campaigns, prospects, messages,
  activities, security_settings, ai_settings, integrations)
- Multi-tenant via `organization_id` on every document
- Auth: JWT (email/password, bcrypt)
- LLM: emergentintegrations + Emergent Universal Key (OpenAI GPT-5.4)
- Modular ProspectSearchProvider (Mock in V1, ready for Google Places / CSV / etc.)

## Core Requirements (static)
1. Dashboard with KPIs + agent grid (Prospect AI active, 5 others "coming soon")
2. Prospect AI dashboard with full search form (target, location, sources, filters,
   AI toggle, service to sell)
3. Prospects table with sort/filter/search/bulk actions/CSV export
4. Prospect detail with AI analysis (score 0-100), notes, message history
5. AI message generator (email/phone/LinkedIn/WhatsApp) editable before send
6. Security Center with all protection toggles + kill switch
7. Campaigns, Analytics (recharts), Activity log, Integrations, Settings
8. Test Mode / Sandbox (banner + simulated sends)
9. Bilingual FR/EN, light/dark theme
10. Responsive desktop / tablet / mobile

## What's been implemented (2026-08-31)
- Full backend API: auth, agents, campaigns, prospects, messages, activities,
  security, integrations, settings (AI + org), analytics, demo seed
- All frontend pages: Login/Register, Dashboard, Agents, ProspectAI, Prospects,
  ProspectDetail, Campaigns, Analytics, Activity, Integrations, Security, Settings
- Multi-tenant isolation on every query
- Test Mode banner, kill switch, JWT auth
- Demo data seeder + clear
- Mock LLM analysis + message generation (real OpenAI call available when test_mode=false)
- Modular ProspectSearchProvider registry
- Bilingual FR/EN + light/dark themes
- Sidebar/topbar with responsive mobile drawer
- CSV export for prospects, sonner toasts, shadcn UI throughout

## Prioritized backlog (P0/P1/P2)
### P0 (post-V1 next iteration)
- Real Google Places / directory provider once user signs up on APIs
- Password reset flow
- Multi-user invite within organization
### P1
- Stripe billing (Starter / Business / Pro) — architecture ready
- Real SMTP integration for actual sends
- Compliance events log (opt-outs, consents)
- CSV import UI
### P2
- Additional agents: Mail AI, Admin AI, Business AI, Content AI, Custom
- Webhook triggers and Zapier/Make deep integration
- Super Admin panel (all organizations)

## Next tasks list
1. Verify UI/UX polish via screenshots and testing agent
2. Fix any critical issues surfaced by the testing agent
3. Consider adding CSV import for prospects (nice-to-have)

---

## V2 Upgrade — 2026-08-31

### What's new
- **Super Admin panel** at `/admin` (protected, superadmin role only): overview, organizations (suspend/reactivate/plan), users (role/suspend), agents catalog, AI usage, platform logs, platform settings. Bootstrapped via `SUPERADMIN_EMAIL` env var (currently `demo@aurahub.io`).
- **RBAC** hardening: `require_min_role` and `get_superadmin` guards; suspended users and suspended orgs are blocked at authentication.
- **Explainable qualification score** per prospect (`qualification_score`, `qualification_status`, `qualification_confidence`, `qualification_reasons[{delta,label,evidence}]`) — deterministic, evidence-based.
- **Facts vs AI assumptions**: `verified_fields[]` and `unverified_fields[]` on every prospect + Hypothesis badge on AI analysis.
- **Provider architecture** (`SearchCriteria.provider`): `mock` (default, forced when Test Mode ON), `google_places` (arch, needs API key), `custom_api` (arch, needs base_url), `csv` (real import endpoint). `is_configured()` is authoritative.
- **CSV import** at `POST /api/prospects/import-csv` with automatic qualification computation.
- **Test Mode confirmation dialog** before disabling; audit log entry `security.test_mode_off` recorded.
- **Kill switch enforcement** on BOTH `POST /messages/{id}/send` and `PATCH /messages/{id}` when status=sent.
- **Integrations truthfulness**: cannot mark `connected=true` without config; secrets (`api_key`, `secret`, `token`, `password`) are redacted with `***` in responses.
- **Structured audit logs**: every Activity carries `action_type`, `entity_type`, `entity_id`.
- **User last_login_at** tracked on login.
- **Compliance metadata** on Prospect (`do_not_contact`, `opted_out`, `existing_customer`, `professional_relevance`, `compliance_status`, `compliance_notes`).
- **Multi-tenant SaaS fields ready**: Organization gets `plan` (demo/starter/business/premium), `plan_status`, `suspended`, `usage_limits`; User gets `suspended`, `last_login_at`; Agent gets `minimum_plan`.
- **Mobile responsive**: Security Center header stacks on mobile, Prospects list swaps to card layout below md breakpoint, admin pages use responsive card/table split.

### Tests
- 71/71 backend tests pass (36 new V2 + 35 V1 regression). File: `/app/backend/tests/test_aura_hub_v2.py`.

### Architecture-only (not yet activated)
- Stripe / billing (fields prepared)
- Mail AI, Admin AI, Business AI, Content AI, Custom Agent
- Real Google Places / SMTP / CRM providers (require API credentials)
